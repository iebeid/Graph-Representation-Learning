import json
import requests
import pandas as pd
import json
from urllib.parse import urlencode


fp_filename = './c2b2rdf.h5'


def getSimilar(query, top):
    params = {'smiles': query, 'top': top}
    qstr = urlencode(params)
    url = f'http://10.253.81.157:8181/getsimilar?{qstr}'
    response = requests.get(url)
    res = response.json()
    data = json.loads(res)
    df = pd.DataFrame(data)
    df['mol_id'].to_csv('data/compound_neighbors.csv', header=None, index=False)
