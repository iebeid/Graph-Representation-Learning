import os
import csv
import argparse
import numpy as np
import pandas as pd
import itertools

def parse_args():
    parser = argparse.ArgumentParser(description="generates compound and target pairs")
    parser.add_argument('--entity1', nargs='?', help='file containing ids of entity1')
    parser.add_argument('--entity1_url', nargs='?', help='entity1 chem2bio2rdf url', default='http://chem2bio2rdf.org/pubchem/resource/pubchem_compound/')
    parser.add_argument('--entity2', nargs='?', help='file containing ids of entity2')
    parser.add_argument('--entity2_url', nargs='?', help='entity2 chem2bio2rdf url', default='http://chem2bio2rdf.org/uniprot/resource/gene/')
    parser.add_argument('--nodes', nargs='?', default='data/c2b2rdf/nodes.txt', help='file containing all nodes in graph')
    parser.add_argument('--output', nargs='?', default='/home/ubuntu/jack/KnowledgeGraphAlgos/data/ctp/compoundgenerelations.csv', help='output path')
    return parser.parse_args()


def read_file(filepath):

    with open(filepath, 'r') as file:
        result = list(set([line.strip() for line in file]))

    return result


def check_in_graph(nodes, node):
    if node not in nodes:
        return False
    return True

def generate_pairs_file(entity1, entity1_url, entity2, entity2_url, nodes, output):

    import time
    start = time.time()
    entity1 = read_file(entity1)
    entity2 = read_file(entity2)
    nodes = read_file(nodes)
    print(f'--- Time to read files: {time.time()-start} seconds ---')


    # pairs = []
    # not_found_entity1 = []
    # not_found_entity2 = []
    # for node1 in entity1:
    #     node1_with_url = os.path.join(entity1_url, node1)
    #     if node1_with_url not in nodes:
    #         not_found_entity1.append(node1)
    #     else:
    #         for node2 in entity2:
    #             node2_with_url = os.path.join(entity2_url, node2)
    #             if node2_with_url not in nodes:
    #                 not_found_entity2.append(node2)
    #             else:
    #                 pair = (node1_with_url, node2_with_url, '1')
    #                 pairs.append(pair)

    # pairs = list(itertools.product(entity1, entity2))
    pairs = list(((os.path.join(entity1_url, compound), os.path.join(entity2_url, gene), 1) for compound in entity1 for gene in entity2))
    return pairs

    # df = pd.DataFrame(pairs)
    # df.to_csv(output, index=False, sep='\t', header=False)

def main(args):
    generate_pairs_file(**args.__dict__)


if __name__ == '__main__':
    args = parse_args()
    main(args)
