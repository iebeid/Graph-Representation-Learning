import os
import json
import time
import pickle
import argparse
import numpy as np
import pandas as pd
from utils.data_utils import getSimilar
from utils.make_pairs import generate_pairs_file
from kg_models.link_pred_model import link_prediction, load_word2vec_model, getlabelmap




def parse_args():
    parser = argparse.ArgumentParser(description="link prediction")
    parser.add_argument('--smile', help='smile string')
    parser.add_argument('--model', default='edge2vec', help='model to use')
    parser.add_argument('--output', nargs='?', default='./data/results.txt', help="file to save predictions on eval file. If None, won't save predictions.")
    return parser.parse_args()

def main(args):
    compounds = 'data/compound_neighbors.csv'
    compounds_url = 'http://chem2bio2rdf.org/pubchem/resource/pubchem_compound/'
    targets = 'data/target.csv'
    target_url = 'http://chem2bio2rdf.org/uniprot/resource/gene/'
    nodes = 'data/nodes.txt'
    data_folder = 'data/'
    relations = 'compoundgenerelations.csv'
    classifier = 'saved_models/xgb.pkl'
    try:
        getSimilar(args.smile, 4)
    except:
        print(f'Error in getting similar compounds for smiles: {args.smile}')
        return -1

    print('--- Generating Pairs File ---')
    pairs_file = os.path.join(data_folder, 'compound_gene_relations.csv')

    try:
        pairs = generate_pairs_file(entity1=compounds, entity1_url=compounds_url, entity2=targets, entity2_url=target_url, nodes=nodes, output=pairs_file)
    except:
        print(f'Error in generating compound gene pairs')
        return -1

    nodemap = getlabelmap(nodes)
    n_nodes = len(nodemap)

    # try:
    if args.model == 'edge2vec':
        print('--- Loading Edge2vec vectors ---')
        vectors = 'emb/edge2vec_vectors.npm'
        start = time.time()
        model = np.memmap(vectors, dtype='float32', mode='r')
        print(f'--- Time to load model ---\n {time.time()-start} seconds\n')
        shape = (n_nodes, len(model)//n_nodes)
        model = model.reshape(shape)

    elif args.model == 'node2vec':
        print('--- Loading Node2vec vectors ---')
        vectors = 'emb/node2vec_vectors.npm'
        start = time.time()
        model = np.memmap(vectors, dtype='float32', mode='r')
        print(f'--- Time to load model ---\n {time.time()-start} seconds\n')

        shape = (n_nodes, len(model)//n_nodes)
        model = model.reshape(shape)

        # print(model_npm[0])
        # print(model_npm_test[0])

    elif args.model == 'hetero':
        print('--- Loading Skip Gram vectors ---')
        vectors = 'emb/hetero_embeddings.pkl'
        # gene_id = 'models/gene_id.npy'
        # gene_ids = np.load(gene_id)
        # embedded_genes = np.load('models/embed_gene.npy')
        # compound_ids = np.load('models/compound_id.npy')
        # embedded_compounds = np.load('models/embed_compound.npy')
        #
        # vector_dict = {}
        # for id, embedding in zip(gene_ids, embedded_genes):
        #     id = os.path.join(target_url, str(id.decode("utf-8")))
        #     vector_dict[id] = embedding
        # for id, embedding in zip(compound_ids, embedded_compounds):
        #     id = os.path.join(compounds_url, str(int(id)))
        #     vector_dict[id] = embedding
        #
        # pickle.dump(vector_dict, open('models/hetero_embeddings.pkl', 'wb'))
        model = pickle.load(open(vectors, 'rb'))

    elif args.model == 'metapath2vec':
        print('--- Loading Metapath2Vec vectors ---')
        vectors = 'emb/metapath2vec_emb.pkl'
        # df = pd.read_csv('emb/metapath2vec_emb.csv')
        # node_names = np.array(df['node_name'])
        # node_vectors =df['node_vector'].values
        # node_vectors_cleaned = []
        # for v in node_vectors:
        #     n = []
        #     v = v[1:-1]
        #     v = v.split(' ')
        #     for val in v:
        #         try:
        #             val = val.strip('\n')
        #             val = float(val)
        #             n.append(val)
        #         except:
        #             pass
        #     n = np.array(n)
        #     node_vectors_cleaned.append(n)
        # node_vectors_cleaned = np.array(node_vectors_cleaned)
        # print(node_vectors_cleaned.shape)
        # vector_dict = {}
        # for name, v in zip(node_names, node_vectors_cleaned):
        #
        #     vector_dict[name] = np.array(v)
        # pickle.dump(vector_dict, open(vectors, 'wb'))

        model = pickle.load(open(vectors, 'rb'))
        print('done')

    elif args.model == 'graphsage':
        print('--- Loading GraphSAGE vectors ---')
        vectors = 'emb/stanford_graphsage_big_emb.pkl'
        embeds = np.load('emb/stanford_graphsage_big_emb.npy')
        with open('emb/big_val.txt') as nodef:
            nodes = [line.strip() for line in nodef]

        embeddings = {}
        for node, vector in zip(nodes, embeds):
            embeddings[node] = vector

        pickle.dump(embeddings, open(vectors, 'wb'))

        model = pickle.load(open(vectors, 'rb'))
        print('done')
    # except:
    #     print(f'Error in loading vectors from {args.model} file')
    #     return -1

    print('--- Predicting Links ---')
    # try:
    link_prediction(model=model, eval_file=pairs, output=args.output, nodemap=nodemap, load_model_path=classifier, model_type=args.model)
    # except:
    #     print('Error in prediction of links between compounds and genes')
    #     return -1

if __name__ == '__main__':
    args = parse_args()
    main(args)
