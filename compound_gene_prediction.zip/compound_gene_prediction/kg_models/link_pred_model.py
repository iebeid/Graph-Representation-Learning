# 1. link prediction. negative pair and positive pair prediction
# 2. prediction result see the correlation pearson and spearman
#remember that need to down sample to equal instance
from gensim.models.keyedvectors import KeyedVectors
import argparse
import random
import numpy as np
import pickle

from sklearn import linear_model
from sklearn import metrics
from sklearn import svm
from sklearn.model_selection import KFold, cross_val_score,cross_val_predict,train_test_split
from sklearn.feature_selection import SelectKBest,chi2,SelectPercentile,mutual_info_classif,SelectFromModel
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier,ExtraTreesClassifier
from xgboost import XGBClassifier

import csv

import matplotlib.pyplot as plt
from sklearn import linear_model

import math
from scipy import stats
from scipy import spatial

def parse_args():
    parser = argparse.ArgumentParser(description="multi_lable_classification")
    parser.add_argument('--vector-file', nargs='?', default='emb/c2b2rdf/vectors.txt', help='node vector')
    parser.add_argument('--pair-file', nargs='?', default='data/c2b2rdf/compound-gene/compoundgenerelations.csv', help='pair relation label')
    parser.add_argument('--eval-file', nargs='?', default='data/c2b2rdf/drugbank/compoundgenerelations.csv', help='extra file for extra evaluations. COVID, probably. ')
    parser.add_argument('--output', nargs='?', default=None, help="file to save predictions on eval file. If None, won't save predictions.")
    parser.add_argument('--node-file', nargs='?', default='data/c2b2rdf/nodes.txt', help='node list')
    parser.add_argument('--num-iter', type=int, default=100, help='Number of times to run training with a different shuffle seed. Default is 100. ')
    parser.add_argument('--save-model', help='save model weights')
    parser.add_argument('--load-model', help='load model weights')
    return parser.parse_args()


def load_word2vec_model(file):
    '''
    return node embedding model
    '''
    model = KeyedVectors.load_word2vec_format(file , binary=False)
    # print model.wv["1"]
    return model

def load_ground_truth(model, pairs, nodemap, model_type='word2vec', num_samples=5000):
    '''
    load ground truth model
    '''
    label = dict()
    # true_label = []
    # instance = []
    count = 0
    data_X = []
    data_Y = []
    orig = []
    for pair in pairs:
        node1 = pair[0]
        node2 = pair[1]
        k = pair[2]
        try:
            if model_type == 'node2vec' or model_type == 'edge2vec':
                vector1 = model[int(nodemap[node1])]
                vector2 = model[int(nodemap[node2])]
            elif model_type == 'metapath2vec':
                # print(node1)
                # print(node2)
                vector1 = model[node1]
                vector2 = model[node2]
                # print(len(vector1))
                # print(len(vector2))

            vector = np.concatenate((vector1,vector2), axis=0)#np.subtract(vector1, vector2) #np.concatenate((vector1,vector2), axis=0)
            data_X.append(vector)
            data_Y.append(k)
            orig.append(str(node1) + " " + str(node2))
            if count % 100 == 0:
                print("build instance",count)
        except KeyError:
            #Uh oh! Looks like a node didn't exist in our training data because of the train/test split. I need to find a way to fix that...
            continue
        count = count + 1
    data_X = np.asarray(data_X)
    data_Y = np.asarray(data_Y)
    return data_X, data_Y, np.asarray(orig)


def score(true_label, predicted):
    acc = metrics.accuracy_score(true_label, predicted)
    f1_marco = metrics.f1_score(true_label, predicted, average='macro')
    f1_micro = metrics.f1_score(true_label, predicted, average='micro')
    precision = metrics.precision_score(true_label, predicted, average='macro')
    recall = metrics.recall_score(true_label, predicted, average='macro')

    avg_score = (acc + f1_marco + f1_micro + precision + recall) / 5.0
    return avg_score

def evaluation_analysis(true_label,predicted):
    '''
    return all metrics results
    '''
    print("accuracy",metrics.accuracy_score(true_label, predicted))
    print("f1 score macro",metrics.f1_score(true_label, predicted, average='macro'))
    print("f1 score micro",metrics.f1_score(true_label, predicted, average='micro'))
    print("precision score",metrics.precision_score(true_label, predicted, average='macro'))
    print("recall score",metrics.recall_score(true_label, predicted, average='macro'))
    print("hamming_loss",metrics.hamming_loss(true_label, predicted))
    print("classification_report", metrics.classification_report(true_label, predicted))
    # print("jaccard_similarity_score", metrics.jaccard_score(true_label, predicted))
    # print("log_loss", metrics.log_loss(true_label, predicted))
    # print("zero_one_loss", metrics.zero_one_loss(true_label, predicted))
    # print("AUC&ROC",metrics.roc_auc_score(true_label, predicted))
    # print("matthews_corrcoef", metrics.matthews_corrcoef(true_label, predicted))

def correlation_analysis(v1,v2):
    '''
    calculated three correlation score between two lists
    '''
    print("spearman correlation:",str(stats.mstats.spearmanr(v1,v2).correlation))
    print("pearsonr correlation:",str(stats.mstats.pearsonr(v1,v2)[0]))
    print("cosine correlation:",1 - spatial.distance.cosine(v1, v2))

def getlabelmap(node_file_path):
    d = dict()

    with open(node_file_path) as nodef:
        for idx, line in enumerate(nodef):
            d[line.strip()] = str(idx)
    print("found %d nodes in dict file" % len(d))
    return d

def predict(clf, x_test, y_test, cross_val=True):
    if cross_val:
        predicted = cross_val_predict(clf, x_test, y_test, cv=2)
    else:
        predicted = clf.predict(x_test)
    return predicted

def evaluate_mat(y_test, predicted):
    evaluation_analysis(y_test, predicted)
    # print("jaccard_similarity_score", metrics.jaccard_similarity_score(y_test, predicted))
    tn, fp, fn, tp = metrics.confusion_matrix(y_test, predicted).ravel()
    print("True Positives: %d" % tp)
    print("True Negatives: %d" % tn)
    print("False Positives: %d" % fp)
    print("False Negatives: %d" % fn)

def evaluate_gui(clf, x_test, y_test):
    print("Evaluating in GUI:")
    # print "log_loss", metrics.log_loss(data_Y, predicted)
    metrics.plot_confusion_matrix(clf, x_test, y_test, cmap=plt.cm.Blues, normalize='true')
    print("Shown!")
    plt.show()
    plot_roc(clf, x_test, y_test)

def link_prediction(model, eval_file, output, nodemap, load_model_path, model_type):
    '''
    return logistic regression all evaluation metrics
    '''

    clf = pickle.load(open(load_model_path, 'rb'))

    # Now do the eval file!
    print('--- LOAD TEST SET ---')
    eval_x, eval_y, pairs = load_ground_truth(model, eval_file, nodemap, num_samples=None, model_type=model_type)
    print(eval_x[0])
    if output is not None:
        with open(output, 'w', newline='') as nfile:
            outwriter = csv.writer(nfile, delimiter='\t',
                quotechar='|', quoting=csv.QUOTE_MINIMAL)
            predicted_scores = clf.predict_proba(eval_x)[:, 1]
            print(np.shape(predicted_scores))
            sorted_idxs = np.lexsort((pairs, predicted_scores))
            sorted_total = [(predicted_scores[i], pairs[i]) for i in sorted_idxs[::-1]] # Sort decending by probability
            for tup in sorted_total:
                outwriter.writerow(tup)

    predicted = predict(clf, eval_x, eval_y, cross_val=False)
    # evaluate_mat(eval_y, predicted)

def calculate_roc(y_true,y_pred):
    '''
    calculate AUROC score
    '''
    auroc = roc_auc_score(y_true, y_pred)
    return auroc

def plot_roc(svc, x_test,y_test):
    '''
    plot the ROC curve
    '''
    metrics.plot_roc_curve(svc, x_test, y_test)
    plt.show()
