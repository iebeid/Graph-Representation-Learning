import sys
import os
sys.path.insert(0, os.path.abspath('..'))

from gensim.models.keyedvectors import KeyedVectors
import argparse
import random
import numpy as np

import math
from scipy import stats
from scipy import spatial

from sklearn import linear_model                                                                                                                                               
from sklearn import metrics 

from sklearn.neural_network import MLPClassifier
from sklearn import svm
from sklearn.utils import shuffle
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import KFold, cross_val_score,cross_val_predict

from eval_utils import *


def parse_args():
    parser = argparse.ArgumentParser(description="Arguments for heterogeneous link prediction.") 
    parser.add_argument('--vector-file', nargs='?', default='emb/wn18/relvectors1000plus.txt', help='node and relation vectors')
    parser.add_argument('--node-file', nargs='?', default='data/wn18/nodes.txt', help='node list')
    parser.add_argument('--edge-file', nargs='?', default='data/wn18/edges.txt', help='edge list')
    parser.add_argument('--test-neg-file', nargs='?', default='data/wn18/test_neg.csv', help='test negatve edges file')
    parser.add_argument('--test-pos-file', nargs='?', default='data/wn18/test_pos.csv', help='test positive edges file')
    parser.add_argument('--train-pos-file', nargs='?', default='data/wn18/train_pos.csv', help='train positive edges file')
    parser.add_argument('--train-neg-file', nargs='?', default='data/wn18/train_neg.csv', help='train negative edges file')

    parser.add_argument('--max-data', type=int, default=10000, help='max number of data points to train/test on')
    return parser.parse_args()

def load_word2vec_model(file):
    '''
    load node embedding model
    '''
    model = KeyedVectors.load_word2vec_format(file , binary=False)
    # print model.wv["1"]
    return model

def triple_to_vec(node, edge, tail, model, edge_embeddings):
    if node not in model:
        print("WTF? A node %s with type %s wasn't in the final embedding!" % (node, type(node)))
        return None
    elif tail not in model:
        print("WTF? A node %s with type %s wasn't in the final embedding!" % (tail, type(tail)))
        return None
    else:
        nodevec = model.wv[node]
        relation = edgepath2str([edge], tail)
        tailvec = model.wv[tail]
        used_general = False
        if relation in model.wv:
            relvec = model.wv[relation]
        elif str2edge(edge) in edge_embeddings:    
            used_general = True        
            relvec = edge_embeddings[str2edge(edge)]
        else:
            # We didn't have ANY relation vectors for this edge. Damn. 
            return None
            #return np.concatenate((nodevec, tailvec))
        return (used_general, np.concatenate((nodevec, relvec, tailvec)))
        
def add_triples(triples, model, data_X, data_Y, maxlen, posorneg):
    num = 0
    edge_embeddings = make_edge_embeddings(model)
    num_general = 0
    use_general = False
    print("Trying to add %d triples with label %d..." % (len(triples), posorneg))
    for node, edge, tail in triples:
        if node in model:
            tup = triple_to_vec(node, edge, tail, model, edge_embeddings)
            if tup is not None:    
                used_general, vec = tup
                if used_general:
                    if use_general:
                        num_general += 1
                    else:
                        continue            
                data_X.append(vec)
                data_Y.append(posorneg)
                num += 1
                if num >= maxlen:
                    break
    print("Added %d relations, of which %d used generalized edges!" % (num, num_general))

def main(args):
    print("Loading model from %s" % args.vector_file)
    model = load_word2vec_model(args.vector_file)
    nodes_dict = load_dict(args.node_file)
    x_train = []
    y_train = []
    x_test = []
    y_test = []
    train_test_split = 0.1
    trainp_triples, trainn_triples, testp_triples, testn_triples = [load_triples(s) for s in [args.train_pos_file, args.train_neg_file, args.test_pos_file, args.test_neg_file]]
    min_len = min(min(len(trainp_triples), len(trainn_triples)), args.max_data)
    trainp_triples = trainp_triples[:min_len]
    trainn_triples = trainn_triples[:min_len]
    add_triples(trainp_triples, model, x_train, y_train, args.max_data, 1)
    add_triples(trainn_triples, model, x_train, y_train, args.max_data, 0)
    add_triples(testp_triples, model, x_test, y_test, int(args.max_data * train_test_split), 1)
    add_triples(testn_triples, model, x_test, y_test, int(args.max_data * train_test_split), 0)
    x_train, y_train = shuffle(x_train, y_train)
    x_test, y_test = shuffle(x_test, y_test)
    train_set = set(trainp_triples)
    print("Fitting model...")
    svc = svm.SVC(probability=True) # KNeighborsClassifier(n_neighbors=20) # linear_model.LogisticRegression(C=1.0, penalty='l2', tol=1e-6, max_iter=300)
    clf = svc.fit(x_train, y_train) #svm
    # array = svc.coef_
    # print array
    predicted = cross_val_predict(clf, x_test, y_test, cv=2)
    evaluate(y_test, predicted)

    print("--------retraining classifier for hits@n rankings--------")
    topns = [1, 3, 10]
    hitsatn = [0, 0, 0]
    mrr_total = 0
    rank_total = 0
    #Now triples_dict contains all relations we know. AND, we have a classifier we can use to score stuff. 
    print("--------calculating top n hits--------")
    count = 0
    test_set = set(testp_triples)
    test_relations = dict()
    # Count the number of each relation type in the test triples. 
    for head, edge, tail in testp_triples:
        if (edge, tail) not in test_relations:
            test_relations[(edge, tail)] = 0
        test_relations[(edge, tail)] += 1
    print("--------Found %d test relations and %d nodes!---------" % (len(test_relations), len(nodes_dict)))
    num_skipped = 0
    edge_embeddings = make_edge_embeddings(model)
    for relationtup, relcount in test_relations.items():
        scorelist = []
        edge, tail = relationtup
        count += 1
        # Given a node and a tail, can we predict the relation between them? Or is there no relation?
        possible_triples = list(filter(lambda triple : triple not in train_set and triple is not None, [(head, edge, tail) for head in nodes_dict.values()]))
        possible_vecs = list(map(lambda triple: triple_to_vec(triple[0], triple[1], triple[2], model, edge_embeddings)[1], possible_triples))
        raw_scores = clf.predict_proba(possible_vecs)[:, 1]
        sorted_score_indices = np.argsort(raw_scores)[::-1]
        sorted_triples = [possible_triples[int(idx)] for idx in sorted_score_indices]
        sorted_scores = [raw_scores[int(idx)] for idx in sorted_score_indices]
        hits = 0
        idx = 0
        while (hits < 1 or idx < (topns[-1])) and idx < len(possible_triples):
            head_guess = sorted_triples[idx]
            if (head_guess, edge, tail) in test_set:
                # A hit!
                hits += 1
                # if hits == relcount:
                    # We've gotten every possible test triple for this relation predicted! 
                    # It turns out precision@K is a flawed metric because we aren't allowed to take this into account. Stupid...
                if hits == 1:
                    # Our first hit! Use this for MRR. 
                    rank = idx + 1
                    mrr_total += 1.0 / rank
                    rank_total += rank
                for nidx, n in enumerate(topns):
                    if idx < n:
                        hitsatn[nidx] += 1
            idx += 1
        if hits == 0:
            # Literally didn't hit anywhere before running out of options. Model, you suck. 
            rank_total += len(possible_triples)
    num_tested = len(test_relations) - num_skipped
    print("%d relations skipped, and tested %d. We had no equivalent in the embedding file. " % (num_skipped, num_tested))
    print("Unnormalized hits: ")
    print(hitsatn)                        
    for idx in range(len(topns)):
        precision =  ((hitsatn[idx] / topns[idx]) / num_tested)
        print("Hits@%d: %f" % (topns[idx], hitsatn[idx] / num_tested))
    print("MRR: %f" % (mrr_total / num_tested))
    print("Mean rank: %f" % (rank_total / num_tested))


if __name__ == "__main__":
    main(parse_args())
