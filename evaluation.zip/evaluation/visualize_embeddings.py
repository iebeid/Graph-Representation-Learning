from gensim.models.keyedvectors import KeyedVectors
import argparse
import random
import numpy as np
from sklearn import linear_model                                                                                                                                               
from sklearn import metrics 
from eval_utils import *
from models.data_utils import *
import tensorflow as tf
from tensorboard.plugins import projector
import io, os


def parse_args():
    parser = argparse.ArgumentParser(description="Visualize em beddings using tensorboard projector") 
    parser.add_argument('--vector-file', nargs='?', default='emb/aifb/relvectors500.txt', help='embedding vectors')
    parser.add_argument('---name', nargs='?', default='', help='Name of trial')
    return parser.parse_args()

def main(args):
    name = args.name
    print("Loading embeddings...")
    embeddings_raw = load_word2vec_model(args.vector_file).wv
    embeddings = dict()
    for word in embeddings_raw.index2word:
        embeddings[word] = embeddings_raw[word]
    print("Loaded!")
    log_dir = "./logs/visualization/"
    # Save Labels separately on a line-by-line manner.
    with open(os.path.join(log_dir, 'metadata.tsv'), "w") as f:
        for word in embeddings.keys():
            f.write("{}\n".format(word))
    # Save the weights we want to analyse as a variable. Note that the first
    # value represents any unknown word, which is not in the metadata, so
    # we will remove that value.
    weights = tf.Variable(np.stack(list(embeddings.values()), axis=0))
    # Create a checkpoint from embedding, the filename and key are
    # name of the tensor.
    checkpoint = tf.train.Checkpoint(embedding=weights)
    checkpoint.save(os.path.join(log_dir, name + "embedding.ckpt"))

    # Set up config
    config = projector.ProjectorConfig()
    embedding = config.embeddings.add()
    # The name of the tensor will be suffixed by `/.ATTRIBUTES/VARIABLE_VALUE`
    embedding.tensor_name = name + "embedding/.ATTRIBUTES/VARIABLE_VALUE"
    embedding.metadata_path = name + 'metadata.tsv'
    projector.visualize_embeddings(log_dir, config)
    
    print("Run tensorboard --logdir=%s" % str(log_dir))

if __name__ == "__main__":
    main(parse_args())
