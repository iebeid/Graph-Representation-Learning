# 1. link prediction. negative pair and positive pair prediction
# 2. prediction result see the correlation pearson and spearman
#remember that need to down sample to equal instance
from gensim.models.keyedvectors import KeyedVectors
import argparse
import random
import numpy as np
import pickle
import os
from sklearn import linear_model
from sklearn import metrics
from sklearn import svm
from sklearn.model_selection import KFold, cross_val_score,cross_val_predict,train_test_split
from sklearn.feature_selection import SelectKBest,chi2,SelectPercentile,mutual_info_classif,SelectFromModel
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier,ExtraTreesClassifier
from xgboost import XGBClassifier

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam, SGD
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.layers import Input, Dense, Add, Flatten, Dropout, Lambda
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau

import csv

import matplotlib.pyplot as plt
from sklearn import linear_model

import math
from scipy import stats
from scipy import spatial

def parse_args():
    parser = argparse.ArgumentParser(description="multi_lable_classification")
    parser.add_argument('--vector-file', nargs='?', default='emb/c2b2rdf/vectors.txt', help='node vector')
    parser.add_argument('--pair-file', nargs='?', default='data/c2b2rdf/compound-gene/compoundgenerelations.csv', help='pair relation label')
    parser.add_argument('--eval-file', nargs='?', default='data/c2b2rdf/drugbank/compoundgenerelations.csv', help='extra file for extra evaluations. COVID, probably. ')
    parser.add_argument('--node-file', nargs='?', default='data/c2b2rdf/nodes.txt', help='node list')
    parser.add_argument('--model', default='edge2vec', help='model type to use')
    return parser.parse_args()


def load_word2vec_model(file):
    '''
    return node embedding model
    '''

    model = KeyedVectors.load_word2vec_format(file , binary=False)
    # print model.wv["1"]
    return model

def getlabelmap(node_file_path):
    d = dict()

    with open(node_file_path) as nodef:
        for idx, line in enumerate(nodef):
            d[line.strip()] = str(idx)
    print("found %d nodes in dict file" % len(d))
    return d

def cosine_similarity(vector1, vector2):
    similarity = float(float(1.0) - (
        spatial.distance.cosine(np.array(vector1, dtype=np.float), np.array(vector2, dtype=np.float))))
    return similarity

def topn_cosine_similarity(model, nodemap, node1, node2_list, model_type='edge2vec'):
    if model_type == 'node2vec' or model_type == 'edge2vec':
        vector = model[nodemap[node1]]
        vector_list = [model[nodemap[node2]] for node2 in node2_list]
    elif model_type == 'metapath2vec' or model_type == 'graphsage':
        vector = model[node1]
        vector_list = [model[node2] for node2 in node2_list]
    result = [(node2, cosine_similarity(vector, v)) for node2, v in zip(node2_list, vector_list)]
    result = sorted(result, key=lambda x: x[1], reverse=True)
    return np.array(result)


def read_file(file):
    compounds = []
    genes = []
    links = []
    with open(file, 'r') as dataf:
        for line in dataf:
            line = line.rstrip().split('\t')
            compounds.append(line[1])
            genes.append(line[0])
            links.append(int(line[2]))

    return [compounds, genes, links]

def generate_cosine_similarity(model, nodemap, data, model_type):

    compounds = data[0]
    genes = data[1]
    links = data[2]

    tp = 0
    fp = 0
    tn = 0
    fn = 0

    sims = {}
    for compound in np.unique(compounds):
        sims[compound] = topn_cosine_similarity(model, nodemap, compound, np.unique(genes), model_type)
    return sims

def top_n_evaluation(sims, data, topn=50):
    compounds = data[0]
    genes = data[1]
    links = data[2]

    tp = 0
    tn = 0
    fp = 0
    fn = 0
    for compound, gene, link in zip(compounds, genes, links):

        topn_sim = sims[compound][:topn]
        if (link == 1) and (gene in topn_sim[:, 0]):
            tp += 1
        elif (link == 0) and (gene not in topn_sim[:, 0]):
            tn += 1
        elif (link == 0) and (gene in topn_sim[:, 0]):
            fp += 1
        elif (link == 1) and (gene not in topn_sim[:, 0]):
            fn += 1
    recall = float(tp)/float(tp+fn)
    precision = float(tp)/float(tp+fp)
    f1 = (2*precision*recall)/float(precision+recall)
    acc = float(tp+tn)/float(tp+tn+fp+fn)

    print(f'True Positive: {tp}')
    print(f'True Negative: {tn}')
    print(f'False Positive: {fp}')
    print(f'False Negative: {fn}')
    print(f'Accuracy: {acc}')
    print(f'Recall: {recall}')
    print(f'Precision: {precision}')
    print(f'F1: {f1}')

    return [acc, recall, precision, f1]

if __name__ == "__main__":
    args = parse_args()
    print("------Loading Word2Vec model-------")
    # if args.model == 'node2vec' or args.model == 'edge2vec':
    #     model = load_word2vec_model(args.vector_file)
    # elif args.model == 'graphsage' or args.model == 'metapath2vec':
    #     model = pickle.load(open(args.vector_file, 'rb'))
    nodemap = getlabelmap(args.node_file)

    internal_data = read_file(args.pair_file)

    # n2v_model = load_word2vec_model('emb/c2b2rdf/test/n2v_vectors.txt')
    # e2v_model = load_word2vec_model('emb/c2b2rdf/test/e2v_vectors2.txt')
    # m2v_model = pickle.load(open('compound_gene_prediction/emb/metapath2vec_emb.pkl', 'rb'))
    gs_model = pickle.load(open('compound_gene_prediction/emb/our_graphsage_emb.pkl', 'rb'))

    model_types = ['node2vec', 'edge2vec', 'metapath2vec', 'graphsage']
    models = [n2v_model, e2v_model, m2v_model, gs_model]
    # model_types = ['graphsage']
    # models= [gs_model]
    writer = csv.writer(open('data/c2b2rdf/test/topn_eval.csv', 'w', newline=''), delimiter=',', quotechar='|')

    for model_type, model in zip(model_types, models):

        cosine_sim = generate_cosine_similarity(model, nodemap, internal_data, model_type=model_type)
        writer.writerow([model_type])
        writer.writerow(['Internal Dataset'])

        print('--- Internal Dataset ---')
        print('--- Top 50 Evaluation ---')
        results = top_n_evaluation(cosine_sim, internal_data, topn=50)

        writer.writerow(['Top 50 Evaluation'])
        writer.writerow(results)

        print('--- Top 100 Evaluation ---')
        results = top_n_evaluation(cosine_sim, internal_data, topn=100)

        writer.writerow(['Top 100 Evaluation'])
        writer.writerow(results)

        print('--- Top 300 Evaluation ---')
        results = top_n_evaluation(cosine_sim, internal_data, topn=300)

        writer.writerow(['Top 300 Evaluation'])
        writer.writerow(results)

        db_data = read_file(args.eval_file)

        writer.writerow(['DrugBank Dataset'])
        print('--- Drugbank Dataset ---')
        print('--- Top 50 Evaluation ---')

        cosine_sim = generate_cosine_similarity(model, nodemap, db_data, model_type)

        results = top_n_evaluation(cosine_sim, db_data, topn=50)

        writer.writerow(['Top 50 Evaluation'])
        writer.writerow(results)

        print('--- Top 100 Evaluation ---')
        results = top_n_evaluation(cosine_sim, db_data, topn=100)

        writer.writerow(['Top 100 Evaluation'])
        writer.writerow(results)

        print('--- Top 300 Evaluation ---')
        results = top_n_evaluation(cosine_sim, db_data, topn=300)

        writer.writerow(['Top 300 Evaluation'])
        writer.writerow(results)
