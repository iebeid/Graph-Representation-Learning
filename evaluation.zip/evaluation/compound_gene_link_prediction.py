# 1. link prediction. negative pair and positive pair prediction
# 2. prediction result see the correlation pearson and spearman
#remember that need to down sample to equal instance
from gensim.models.keyedvectors import KeyedVectors
import argparse
import random
import numpy as np
import pickle
import os
from sklearn import linear_model
from sklearn import metrics
from sklearn import svm
from sklearn.model_selection import KFold, cross_val_score,cross_val_predict,train_test_split
from sklearn.feature_selection import SelectKBest,chi2,SelectPercentile,mutual_info_classif,SelectFromModel
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier,ExtraTreesClassifier
from xgboost import XGBClassifier

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam, SGD
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.layers import Input, Dense, Add, Flatten, Dropout, Lambda
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau

import csv

import matplotlib.pyplot as plt
from sklearn import linear_model

import math
from scipy import stats
from scipy import spatial

def parse_args():
    parser = argparse.ArgumentParser(description="multi_lable_classification")
    parser.add_argument('--vector-file', nargs='?', default='emb/c2b2rdf/vectors.txt', help='node vector')
    parser.add_argument('--pair-file', nargs='?', default='data/c2b2rdf/compound-gene/compoundgenerelations.csv', help='pair relation label')
    parser.add_argument('--eval-file', nargs='?', default='data/c2b2rdf/drugbank/compoundgenerelations.csv', help='extra file for extra evaluations. COVID, probably. ')
    parser.add_argument('--output', nargs='?', default=None, help="file to save predictions on eval file. If None, won't save predictions.")
    parser.add_argument('--node-file', nargs='?', default='data/c2b2rdf/nodes.txt', help='node list')
    parser.add_argument('--num-iter', type=int, default=100, help='Number of times to run training with a different shuffle seed. Default is 100. ')
    parser.add_argument('--save-model', help='save model weights')
    parser.add_argument('--load-model', help='load model weights')
    parser.add_argument('--model', default='edge2vec', help='model type to use')
    return parser.parse_args()


def load_word2vec_model(file):
    '''
    return node embedding model
    '''

    model = KeyedVectors.load_word2vec_format(file , binary=False)
    # print model.wv["1"]
    return model

def cosine_similarity(vector1, vector2):
    similarity = float(float(1.0) - (
        spatial.distance.cosine(np.array(vector1, dtype=np.float), np.array(vector2, dtype=np.float))))
    return similarity



def load_ground_truth(model,ground_truth_file,nodemap, num_samples=5000, model_type='word2vec'):
    '''
    load ground truth model
    '''
    # label = dict()
    # true_label = []
    # instance = []
    # count = 0
    # with open(ground_truth_file) as f:
    #     for line in f:
    #         count = count+1
    #         result = line.rstrip().split("\t")
    #         node1 = result[0]
    #         node2 = result[1]
    #         n_label = result[2]
    #         # true_label.append(int(relation))
    #         # vector1 = model.wv[node1]
    #         # vector2 = model.wv[node2]
    #         # vector = np.subtract(vector1, vector2) #np.concatenate((vector1,vector2), axis=0)
    #         if n_label in label:
    #             label[n_label].append(line.rstrip())
    #         else:
    #             label_list = []
    #             label_list.append(line.rstrip())
    #             label[n_label] = label_list
    #         # instance.append(vector)
    #         if count % 10000 == 0:
    #         # print vector,relation
    #             print("load data",str(count))
    #
    # # data_Y = np.asarray(true_label)
    # # data_X = np.asarray(instance)
    #
    #
    # #sample equal instance
    # min_len = num_samples
    # for k,v in label.items():
    #     random.shuffle(v)
    #     if num_samples is not None and len(v)<min_len:
    #         min_len = len(v)
    #
    #
    # new_label = dict()
    # for k,v in label.items():
    #     new_list= []
    #     r = min_len
    #     if min_len is None:
    #         r = len(v)
    #     for i in range(r):
    #         new_list.append(v[i])
    #     new_label[k] = new_list
    # print("min_len")
    # print(min_len)
    #
    # #build instances
    # data_X = []
    # data_Y = []
    # embedding_preds = []
    # orig = []
    # count = 0
    # for k,v in new_label.items():
    #     for l in v:
    #         result = l.rstrip().split("\t")
    #         node1 = result[0]
    #         node2 = result[1]
    #         # print(node1)
    #         try:
    #             if model_type == 'node2vec' or model_type == 'edge2vec':
    #                 vector1 = model[nodemap[node1]]
    #                 vector2 = model[nodemap[node2]]
    #             elif model_type == 'graphsage' or model_type == 'metapath2vec':
    #                 vector1 = model[node1]
    #                 vector2 = model[node2]
    #             embedding_pred = cosine_similarity(vector1, vector2)
    #             embedding_preds.append(embedding_pred)
    #             vector = np.concatenate((vector1,vector2), axis=0)#np.subtract(vector1, vector2) #np.concatenate((vector1,vector2), axis=0)
    #             data_X.append(vector)
    #             data_Y.append(int(k))
    #             orig.append(str(node1) + " " + str(node2))
    #             # if count % 100 == 0:
    #                 # print("build instance",count)
    #         except KeyError:
    #             #Uh oh! Looks like a node didn't exist in our training data because of the train/test split. I need to find a way to fix that...
    #             continue
    #         count = count + 1

    data_X = []
    data_Y = []
    embedding_preds = []
    orig = []
    with open(ground_truth_file) as f:
        for line in f:
            result = line.rstrip().split("\t")
            node1 = result[0]
            node2 = result[1]
            label = int(result[2])
            # print(node1)
            try:
                if model_type == 'node2vec' or model_type == 'edge2vec':
                    vector1 = model[nodemap[node1]]
                    vector2 = model[nodemap[node2]]
                elif model_type == 'graphsage' or model_type == 'metapath2vec':
                    vector1 = model[node1]
                    vector2 = model[node2]
                embedding_pred = cosine_similarity(vector1, vector2)
                embedding_preds.append(embedding_pred)
                vector = np.concatenate((vector1,vector2), axis=0)#np.subtract(vector1, vector2) #np.concatenate((vector1,vector2), axis=0)
                data_X.append(vector)
                data_Y.append(label)
                orig.append(str(node1) + " " + str(node2))
            except:
                pass
    data_X = np.asarray(data_X)
    data_Y = np.asarray(data_Y)
    orig = np.asarray(orig)
    embedding_preds = np.asarray(embedding_preds)
    shuffle = np.random.choice(data_X.shape[0], len(data_X), replace=False)
    data_X = data_X[shuffle]
    data_Y = data_Y[shuffle]
    orig = orig[shuffle]
    embedding_preds = embedding_preds[shuffle]

    return data_X, data_Y, orig, embedding_preds



def score(true_label, predicted):
    acc = metrics.accuracy_score(true_label, predicted)
    f1_marco = metrics.f1_score(true_label, predicted, average='macro')
    f1_micro = metrics.f1_score(true_label, predicted, average='micro')
    precision = metrics.precision_score(true_label, predicted, average='macro')
    recall = metrics.recall_score(true_label, predicted, average='macro')

    avg_score = (acc + f1_marco + f1_micro + precision + recall) / 5.0
    return avg_score

def threshold_eval(predicted, y_true, threshold):
    acc = 0

    for pred, yt in zip(predicted, y_true):
        if pred > threshold and yt == 1:
            acc += 1
        elif pred < (1-threshold) and yt == 0:
            acc += 1

    return float(acc)/float(len(y_true))
def accuracy_per_threshold(predicted, y_true):
    print(f'Accuracy for threshold 0.5: {threshold_eval(predicted, y_true, 0.5)}')
    print(f'Accuracy for threshold 0.7: {threshold_eval(predicted, y_true, 0.7)}')
    print(f'Accuracy for threshold 0.8: {threshold_eval(predicted, y_true, 0.8)}')
    print(f'Accuracy for threshold 0.9: {threshold_eval(predicted, y_true, 0.9)}')

def evaluation_analysis(true_label,predicted):
    '''
    return all metrics results
    '''
    print("accuracy",metrics.accuracy_score(true_label, predicted))
    # print("f1 score macro",metrics.f1_score(true_label, predicted, average='macro'))
    print("f1 score micro",metrics.f1_score(true_label, predicted, average='binary'))
    print("precision score",metrics.precision_score(true_label, predicted, average='binary', zero_division=1))
    print("recall score",metrics.recall_score(true_label, predicted, average='binary', zero_division=1))
    print("hamming_loss",metrics.hamming_loss(true_label, predicted))
    # print("classification_report", metrics.classification_report(true_label, predicted))
    # print("jaccard_similarity_score", metrics.jaccard_score(true_label, predicted))
    # print("log_loss", metrics.log_loss(true_label, predicted))
    # print("zero_one_loss", metrics.zero_one_loss(true_label, predicted))
    # print("AUC&ROC",metrics.roc_auc_score(true_label, predicted))
    # print("matthews_corrcoef", metrics.matthews_corrcoef(true_label, predicted))

def correlation_analysis(v1,v2):
    '''
    calculated three correlation score between two lists
    '''
    print("spearman correlation:",str(stats.mstats.spearmanr(v1,v2).correlation))
    print("pearsonr correlation:",str(stats.mstats.pearsonr(v1,v2)[0]))
    print("cosine correlation:",1 - spatial.distance.cosine(v1, v2))

def getlabelmap(node_file_path):
    d = dict()

    with open(node_file_path) as nodef:
        for idx, line in enumerate(nodef):
            d[line.strip()] = str(idx)
    print("found %d nodes in dict file" % len(d))
    return d

def predict(clf, x_test, y_test, cross_val=True):
    if cross_val:
        predicted = cross_val_predict(clf, x_test, y_test, cv=2)
    else:
        predicted = clf.predict(x_test)
    return predicted

def evaluate_mat(y_test, predicted):
    evaluation_analysis(y_test, predicted)
    # print("jaccard_similarity_score", metrics.jaccard_similarity_score(y_test, predicted))
    tn, fp, fn, tp = metrics.confusion_matrix(y_test, predicted).ravel()
    print("True Positives: %d" % tp)
    print("True Negatives: %d" % tn)
    print("False Positives: %d" % fp)
    print("False Negatives: %d" % fn)

def evaluate_gui(clf, x_test, y_test):
    print("Evaluating in GUI:")
    # print "log_loss", metrics.log_loss(data_Y, predicted)
    metrics.plot_confusion_matrix(clf, x_test, y_test, cmap=plt.cm.Blues, normalize='true')
    print("Shown!")
    plt.show()
    plot_roc(clf, x_test, y_test)

def logit_regression(model, ground_truth_file, eval_file, output, nodemap, num_iter, save_model_path, load_model_path, model_type):
    '''
    return logistic regression all evaluation metrics
    '''

    # print data_X,data_Y
    # svc = svm.SVC(C=1, kernel='linear')
    data_X, data_Y, _, embedding_preds = load_ground_truth(model, ground_truth_file, nodemap, num_samples=None, model_type=model_type)

    # dot_score = np.sum([1 for y_pred, y_true in zip(embedding_preds, data_Y) if (y_pred > 0.5 and int(y_true) == 1)])
    # dot_score /= float(len(data_Y))
    # print(dot_score)

    count = 0

    if load_model_path:
        load_model_names = ['_lr_test.pkl', '_xgb_test.pkl', '_rf_test.pkl']
        best_model = []
        for clf in load_model_names:

            best_model.append(pickle.load(open(load_model_path+clf, 'rb')))
    else:
        lr_clf = linear_model.LogisticRegression(C=1.0, penalty='l2', tol=1e-6, max_iter=300)
        xgb_clf = XGBClassifier()
        rf_clf = RandomForestClassifier()

        clfs = [lr_clf, xgb_clf, rf_clf]

        best_model = [None, None, None]
        save_model_names = ['_lr_test.pkl', '_xgb_test.pkl', '_rf_test.pkl']
        for idx, clf in enumerate(clfs):
            total_y_test = None
            total_predicted = None
            total_prob_predicted = None
            best_score = -1
            for i in range(num_iter):
                X_train, x_test, y_train, y_test = train_test_split(data_X, data_Y, test_size=0.1, random_state=i)
                # y_train = to_categorical(y_train)
                # y_test = to_categorical(y_test)
                clf.fit(X_train, y_train)
                # clf.fit(X_train, y_train, epochs=10, validation_data=(x_test, y_test), verbose=1, batch_size=32) #svm
                # array = svc.coef_
                # print array
                print("On iter %d/%d" % (i, num_iter))
                predicted = predict(clf, x_test, y_test, cross_val=False)
                prob_pred = clf.predict_proba(x_test)[:, 1]
                # predicted = np.argmax(predicted, axis=1)
                model_score = score(y_test, predicted)
                if best_score < model_score:
                    best_model[idx] = clf

                if total_y_test is None:
                    total_y_test = y_test
                    total_predicted = predicted
                    total_prob_predicted = prob_pred
                else:
                    # y_test = np.argmax(y_test, axis=1)
                    total_y_test = np.concatenate([total_y_test, y_test])
                    total_predicted = np.concatenate([total_predicted, predicted])
                    total_prob_predicted = np.concatenate([total_prob_predicted, prob_pred])
            evaluate_mat(total_y_test, total_predicted)
            accuracy_per_threshold(total_prob_predicted, total_y_test)
            if save_model_path:
                pickle.dump(best_model[idx], open(save_model_path+save_model_names[idx], 'wb'))
    # Now do the eval file!
    print('--- LOAD TEST SET ---')
    eval_x, eval_y, pairs, embedding_preds = load_ground_truth(model, eval_file, nodemap, num_samples=None, model_type=model_type)
    # print([score for score in embedding_preds])

    if output is not None:
        with open(output, 'w', newline='') as nfile:
            outwriter = csv.writer(nfile, delimiter='\t',
                quotechar='|', quoting=csv.QUOTE_MINIMAL)
            predicted_scores = clf.predict_proba(eval_x)[:, 1]
            print(np.shape(predicted_scores))
            sorted_idxs = np.lexsort((pairs, predicted_scores))
            sorted_total = [(predicted_scores[i], pairs[i]) for i in sorted_idxs[::-1]] # Sort decending by probability
            for tup in sorted_total:
                outwriter.writerow(tup)
    for clf in best_model:
        predicted_scores = clf.predict_proba(eval_x)[:, 1]
        predicted = predict(clf, eval_x, eval_y, cross_val=False)
        evaluate_mat(eval_y, predicted)
        accuracy_per_threshold(predicted_scores, eval_y)
    # name = os.path.basename(save_model_path)
    # name = name.replace('txt', '')
    # results = f'{name}\nAccuracy for threshold 0.5: {float(sum([pred > 0.5 for pred in predicted_scores]))/float(len(predicted_scores))}\nAccuracy for threshold 0.7: {float(sum([pred > 0.7 for pred in predicted_scores]))/float(len(predicted_scores))}\nAccuracy for threshold 0.8: {float(sum([pred > 0.8 for pred in predicted_scores]))/float(len(predicted_scores))}\nAccuracy for threshold 0.9: {float(sum([pred > 0.9 for pred in predicted_scores]))/float(len(predicted_scores))}\n'

    # with open(output, 'a', newline='') as out_file:
    #     out_file.write(results)

def calculate_roc(y_true,y_pred):
    '''
    calculate AUROC score
    '''
    auroc = roc_auc_score(y_true, y_pred)
    return auroc

def plot_roc(svc, x_test,y_test):
    '''
    plot the ROC curve
    '''
    metrics.plot_roc_curve(svc, x_test, y_test)
    plt.show()

if __name__ == "__main__":
    args = parse_args()
    print("------Loading Word2Vec model-------")
    if args.model == 'node2vec' or args.model == 'edge2vec':
        model = load_word2vec_model(args.vector_file)
    elif args.model == 'graphsage' or args.model == 'metapath2vec':
        model = pickle.load(open(args.vector_file, 'rb'))
    nodemap = getlabelmap(args.node_file)
    print("Testing with %d iterations" % args.num_iter)
    logit_regression(model,args.pair_file,args.eval_file,args.output,nodemap, args.num_iter, args.save_model, args.load_model, model_type=args.model)

    # for p in [2, 5, 10]:
    #     for q in [0.1, 0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 5, 10]:
    #         print("------Loading Word2Vec model-------")
    #         path = '/home/ubuntu/jack/KnowledgeGraphAlgos/emb/c2b2rdf/test'
    #         vector_file = os.path.join(path, f'e2v_vectors_p_{p}_q_{q}.txt')
    #         if args.model == 'node2vec' or args.model == 'edge2vec':
    #             model = load_word2vec_model(vector_file)
    #         elif args.model == 'hetero':
    #             model = pickle.load(open(args.vector_file, 'rb'))
    #         nodemap = getlabelmap(args.node_file)
    #         print("Testing with %d iterations" % args.num_iter)
    #         save_model_path = '/home/ubuntu/jack/KnowledgeGraphAlgos/data/c2b2rdf/test'
    #         save_model = os.path.join(save_model_path, f'e2v_xgb_p_{p}_q_{q}.txt')
    #         logit_regression(model,args.pair_file,args.eval_file,args.output,nodemap, args.num_iter, save_model, args.load_model, model_type=args.model)
