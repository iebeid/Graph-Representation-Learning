#remember that need to down sample to equal instance
from gensim.models.keyedvectors import KeyedVectors
import argparse
import random
import numpy as np
from sklearn import linear_model                                                                                                                                               
from sklearn import metrics 
from eval_utils import *

from sklearn import svm
from sklearn.model_selection import KFold, cross_val_score,cross_val_predict,train_test_split
from sklearn.feature_selection import SelectKBest,chi2,SelectPercentile,mutual_info_classif,SelectFromModel 
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier,ExtraTreesClassifier

def parse_args():
    parser = argparse.ArgumentParser(description="multi_lable_classification") 
    parser.add_argument('--vector-file', nargs='?', default='emb/bgs/relvectors500.txt', help='node vector')
    parser.add_argument('--label-file', nargs='?', default='data/bgs/labels.txt', help='node label')
    parser.add_argument('--node-file', nargs='?', default='data/bgs/nodes.txt', help='node list')
    parser.add_argument('--num-iter', type=int, default=100, help='Number of iterations for train/test splitting.')
    return parser.parse_args()

def load_word2vec_model(file):
    '''
    load node embedding model
    '''
    model = KeyedVectors.load_word2vec_format(file , binary=False)
    # print model.wv["1"]
    return model

def sample_equal_instance(ground_truth_file):
    '''
    sample equal instance from the ground truth file
    '''
    label = dict()
    with open(ground_truth_file) as f:
        for line in f:
            result = line.rstrip().split("\t")
            if len(result) != 2:
                print("Strange line %s " % line)
            node = result[0]
            n_label = result[1] 
            if n_label in label:
                label[n_label].append(node)
            else:
                label_list = []
                label_list.append(node)
                label[n_label] = label_list
    min_len = 10000
    min_min_len = 10 #Minimum amount you'll shrink min_len to. 
    for k,v in label.items():
        random.shuffle(v)
        if len(v)<min_len and len(v) > min_min_len:
            min_len = len(v)
    print("MIN LEN: %d" % min_len)
    new_label = dict()
    for k,v in label.items():
        new_list= []
        for i in range(min_len):
            new_list.append(v[i])
        new_label[k] = new_list
    return new_label

def data_reshape(model,label, labelmap):
    '''
    reshape the data frame
    '''
    data_X = []
    data_Y = []
    for k,v in label.items(): 
        for l in v: 
            data_X.append(model.wv[labelmap[l]])
            data_Y.append(k)
    data_X = np.asarray(data_X)
    data_Y = np.asarray(data_Y)
    return data_X,data_Y

def multi_class_classification(data_X,data_Y, num_iter):
    '''
    calculate multi-class classification and return related evaluation metrics
    '''
    svc = linear_model.LogisticRegression(C=1.0, penalty='l2', tol=1e-6, max_iter=300)
    max_size = 10000
    # array = svc.coef_
    # print array
    total_y_test = None
    total_predicted = None
    for i in range(num_iter):        
        x_train, x_test, y_train, y_test = train_test_split( data_X, data_Y, test_size=0.5, random_state=i) 
        x_train = x_train[:max_size]
        y_train = y_train[:max_size]
        x_test = x_test[:max_size]
        y_test = y_test[:max_size]
        clf = svc.fit(x_train, y_train) #svm
        # array = svc.coef_
        # print array
        print("On iter %d/%d" % (i, num_iter))
        predicted = cross_val_predict(clf, x_test, y_test, cv=2)
        if total_y_test is None:
            total_y_test = y_test
            total_predicted = predicted
        else:
            total_y_test = np.concatenate([total_y_test, y_test])
            total_predicted = np.concatenate([total_predicted, predicted])
    # print "AUC&ROC",metrics.roc_auc_score(data_Y, predicted)
    # print "matthews_corrcoef", metrics.matthews_corrcoef(data_Y, predicted)
    evaluate(total_y_test, total_predicted)


if __name__ == "__main__":
    args = parse_args()
    nodemap = load_dict(args.node_file)
    print("Loading embeddings....")
    vector = load_word2vec_model(args.vector_file)  
    print("found %d nodes in model" % len(vector.vocab))
    label = sample_equal_instance(args.label_file)
    data_X, data_Y = data_reshape(vector,label, nodemap)
    # print data_X,data_Y
    # print type(data_X),len(data_X)
    multi_class_classification(data_X,data_Y, args.num_iter)







