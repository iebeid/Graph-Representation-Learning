import sys
import os
sys.path.insert(0, os.path.abspath('..'))

from gensim.models.keyedvectors import KeyedVectors
import argparse
import random
import numpy as np

import math
from scipy import stats
from scipy import spatial

from sklearn import linear_model                                                                                                                                               
from sklearn import metrics 

from sklearn.neural_network import MLPClassifier
from sklearn import svm
from sklearn.model_selection import KFold, cross_val_score,cross_val_predict

from eval_utils import *

def parse_args():
    parser = argparse.ArgumentParser(description="Arguments for heterogeneous link prediction.") 
    parser.add_argument('--vector-file', nargs='?', default='emb/wn18/pathvectors1000plus.txt', help='node and relation vectors')
    parser.add_argument('--node-file', nargs='?', default='data/wn18/nodes.txt', help='node list')
    parser.add_argument('--edge-file', nargs='?', default='data/wn18/edges.txt', help='edge list')
    parser.add_argument('--test-neg-file', nargs='?', default='data/wn18/test_neg.csv', help='test negatve edges file')
    parser.add_argument('--test-pos-file', nargs='?', default='data/wn18/test_pos.csv', help='test positive edges file')
    parser.add_argument('--train-pos-file', nargs='?', default='data/wn18/train_pos.csv', help='train positive edges file')

    parser.add_argument('--max-test', type=int, default=1000, help='number of testing data points')
    return parser.parse_args()

def load_word2vec_model(file):
    '''
    load node embedding model
    '''
    model = KeyedVectors.load_word2vec_format(file , binary=False)
    # print model.wv["1"]
    return model
def make_filter_method(edge, tail, train_set):
    def filter_scores(intuple):
        head = intuple[0]
        if "EDGE" in head:
            return False
        new_trip = (head, edge, tail)
        if new_trip in train_set:
            return False # Don't score the model on how well it can regurgitate the training data. 
        return True
    return filter_scores
    
if __name__ == "__main__":
    args = parse_args()
    nodes_dict = load_dict(args.node_file)
    edges_dict = load_dict(args.edge_file)
    print("--------Loading word2vec model--------")
    word2vec_model = load_word2vec_model(args.vector_file)
    print("--------Loading test triples--------")
    test_pos_triples = load_triples(args.test_pos_file)
    train_pos_triples = load_triples(args.train_pos_file)
    train_set = set(train_pos_triples)
    test_neg_triples = load_triples(args.test_neg_file)
    # Maybe a similarity search would work better. After all, because edge-tail pairs and heads are near each other in walks,
    # they shold be close to each other in vector space. 
    # Now, also measure Hits@K and MRR            
    print("--------retraining classifier for hits@n rankings--------")
    topns = [1, 3, 10]
    hitsatn = [0, 0, 0]
    mrr_total = 0
    rank_total = 0
    #Now triples_dict contains all relations we know. AND, we have a classifier we can use to score stuff. 
    print("--------calculating top n hits--------")
    count = 0
    test_set = set(test_pos_triples)
    test_relations = dict()
    # Count the number of each relation type in the test triples. 
    for head, edge, tail in test_pos_triples:
        if (edge, tail) not in test_relations:
            test_relations[(edge, tail)] = 0
        test_relations[(edge, tail)] += 1
    print("--------Found %d test relations!---------" % len(test_relations))
    num_skipped = 0
    edge_embeddings = make_edge_embeddings(word2vec_model)
    skip_generals = True
    word2vec_model.add(list(map(lambda edge: edge2str(int(edge)), edge_embeddings.keys())), list(edge_embeddings.values()))
    for relationtup, relcount in test_relations.items():
        scorelist = []
        edge, tail = relationtup
        count += 1
        relation = edgepath2str([edge], tail)
        most_similar = []
        if relation in word2vec_model:
            most_similar = [relation]
        else:
            if skip_generals:
                # We never saw this one while walking. For now, just skip it.
                num_skipped += 1 
                continue
            most_similar = [edge, tail]
        # Given a node and a tail, can we predict the relation between them? Or is there no relation?
        filter_func = make_filter_method(edge, tail, train_set)
        score_arr = word2vec_model.most_similar(positive=most_similar, negative=None, topn = None)
        # score_arr = word2vec_model.similar_by_word(relation, None)
        scorelist = zip(word2vec_model.index2word, score_arr)
        filtered_scores = list(filter(filter_func, scorelist))
        sorted_scores = sorted(filtered_scores, key = lambda x : x[1], reverse=True)
        hits = 0
        idx = 0
        while (hits < 1 or idx < (topns[-1])):
            head_guess = sorted_scores[idx][0]
            if (head_guess, edge, tail) in test_set:
                # A hit!
                hits += 1
                # if hits == relcount:
                    # We've gotten every possible test triple for this relation predicted! 
                    # It turns out precision@K is a flawed metric because we aren't allowed to take this into account. Stupid...
                if hits == 1:
                    # Our first hit! Use this for MRR. 
                    rank = idx + 1
                    mrr_total += 1.0 / rank
                    rank_total += rank
                for nidx, n in enumerate(topns):
                    if idx < n:
                        hitsatn[nidx] += 1
            idx += 1
        if hits == 0:
            # We never hit it, which should be impossible if we iterated over every head. 
            print(relation)
    num_tested = len(test_relations) - num_skipped
    print("%d relations skipped, and tested %d. We had no equivalent in the embedding file. " % (num_skipped, num_tested))
    print("Unnormalized hits: ")
    print(hitsatn)                        
    for idx in range(len(topns)):
        precision =  ((hitsatn[idx] / topns[idx]) / num_tested)
        print("Hits@%d: %f" % (topns[idx], hitsatn[idx] / num_tested))
    print("MRR: %f" % (mrr_total / num_tested))
    print("Mean rank: %f" % (rank_total / num_tested))
        
    
                        


                
                